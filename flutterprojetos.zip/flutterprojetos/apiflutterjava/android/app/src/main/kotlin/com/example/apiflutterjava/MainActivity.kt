package com.example.apiflutterjava

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
