import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(

      home:Scaffold(
        appBar: AppBar(
          title: Text('Tela de API')),
          body: MyApiBody(),
        ),
    );
  }
}

class MyApiBody extends StatefulWidget{
  @override
  _MyApiBodyState createState() => _MyApiBodyState();

}
class _MyApiBodyState extends State<MyApiBody>{
  List<dynamic> data = [];

  Future<void> fetchData() async {
    try {
      final response = await http.get(
          Uri.parse('http://localhost:8080/livro/'),
          );
          if (response.statusCode == 200) {
        setState(() {
          data = json.decode(response.body);
        });
      } else {
    setState(() {
    data = [];
    // Se houver um erro na resposta da API, você pode exibir uma mensagem de erro ou tratar de outra forma
    });
    }
    } catch (e) {
    setState(() {
    data = [];
    // Se houver um erro de conexão, você pode exibir uma mensagem de erro ou tratar de outra forma
    });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        ElevatedButton(
          onPressed: fetchData,
          child: Text('GET'),
        ),
        SizedBox(height: 20),
        Expanded(
          child: ListView.builder(
            itemCount: data.length,
            itemBuilder: (context, index) {
              final produto = data[index];
              return ListTile(
                title: Text(produto['autor']),
                subtitle: Text(produto['editora']),
              );
            },
          ),
        ),
      ],
    );
  }
}

